from .lib import main_func

def main():
    main_func()